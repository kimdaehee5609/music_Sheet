## Authors

Lyluatex is developped by:

- [Fr. Jacques Peron](mailto:catacolp@hotmail.com);
- Urs Liska;
- Br. Samuel Springuel.
